package com.dennismwebia.angar.utils;

import android.view.View;

/**
 * Created by dennis on 2/23/18.
 */

public interface CustomClickListener {
    public void onItemClick(View view, int position);
}
